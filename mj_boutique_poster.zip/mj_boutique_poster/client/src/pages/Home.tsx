import { useState } from "react";
import { MessageCircle, Phone, Truck } from "lucide-react";

/**
 * MJ BOUTIQUE POSTER PAGE
 * Design Philosophy: Premium Beverage Retail
 * - Elegant dark background with gold accents
 * - Professional logo with wine glass design
 * - Product showcase grid with professional typography
 * - Location information prominently displayed
 * - Contact information and delivery details
 * - High-end retail aesthetic
 */

interface Product {
  name: string;
  image: string;
}

const products: Product[] = [
  { name: "Savanna", image: "/images/441fIfnCPkUW.png" },
  { name: "Martini Rosato", image: "/images/089DRlB84VJF.jpg" },
  { name: "Martini Bianca", image: "/images/5TEV7fwt8HEC.png" },
  { name: "Desperados", image: "/images/kf5ykZgyVMpu.jpg" },
  { name: "Hennessy", image: "/images/2ZeFod3EjGoJ.jpeg" },
  { name: "Jack Daniel's", image: "/images/XSSMHXK1TVQg.png" },
  { name: "JP Chenet Rosé", image: "/images/SUUZ29znvfbr.png" },
  { name: "Vat 69", image: "/images/MzlXnAP01Jch.jpg" },
  { name: "Belaire Rosé", image: "/images/eGUhlBHq1vsZ.jpg" },
  { name: "Gold Label Reserve", image: "/images/JjdtfBUtal5L.jpg" },
  { name: "Campari", image: "/images/kz2p5rYObD8e.jpg" },
  { name: "Absolut Vodka", image: "/images/leL7vCTlSOoX.jpg" },
  { name: "Ballantine's", image: "/images/roUYGE2zZofA.png" },
  { name: "Red Label", image: "/images/aSLdzKFNqUYk.png" },
  { name: "Grant's", image: "/images/fEtEaR3xf6Tz.jpg" },
  { name: "Label 5", image: "/images/rvzGkK11z9wa.jpg" },
];

export default function Home() {
  const [showQRInfo, setShowQRInfo] = useState(false);

  const generateQRCode = () => {
    const posterData = `MJ BOUTIQUE - COCOTOMEY
Pharmacie Concorde - Centre Impact Action
Produits Premium: Vins, Alcools, Bières, Sucreries
https://mj-boutique.manus.space`;

    const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=${encodeURIComponent(posterData)}`;
    window.open(qrUrl, "_blank");
  };

  const handleWhatsApp = () => {
    window.open("https://wa.me/", "_blank");
  };

  const handleMomo = () => {
    alert("Compte Momo: 0157579538");
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950 text-white">
      {/* Main Poster Section */}
      <div id="poster-content" className="w-full max-w-6xl mx-auto px-4 py-12">
        {/* Logo Section */}
        <div className="text-center mb-8 pt-4">
          <img
            src="/images/logo_mj_boutique.jpg"
            alt="MJ Boutique Logo"
            className="h-32 md:h-40 mx-auto object-contain mb-6"
          />
        </div>

        {/* Header Section */}
        <div className="text-center mb-12">
          <h1 className="text-5xl md:text-6xl font-bold mb-3 bg-gradient-to-r from-amber-300 via-amber-200 to-amber-400 bg-clip-text text-transparent">
            MJ BOUTIQUE
          </h1>
          <div className="h-1 w-32 bg-gradient-to-r from-amber-400 to-amber-300 mx-auto mb-4"></div>
          <p className="text-lg md:text-xl text-amber-100 font-light tracking-widest">
            PREMIUM BEVERAGES & CONFECTIONERY
          </p>
        </div>

        {/* Location Information */}
        <div className="bg-gradient-to-r from-amber-900/30 to-amber-800/20 border border-amber-400/30 rounded-lg p-8 mb-12 backdrop-blur-sm">
          <div className="text-center">
            <p className="text-sm uppercase tracking-widest text-amber-200 mb-2">
              📍 LOCALISATION
            </p>
            <h2 className="text-3xl md:text-4xl font-bold text-amber-50 mb-3">
              Cocotomey
            </h2>
            <p className="text-lg text-amber-100 mb-2">
              À côté de la Pharmacie Concorde
            </p>
            <p className="text-lg text-amber-100 mb-2">
              Juste devant le Centre de Formation Impact Action
            </p>
            <p className="text-lg text-amber-100">
              Au bord des pavés
            </p>
          </div>
        </div>

        {/* Contact & Delivery Section */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          {/* Momo Payment */}
          <div className="bg-gradient-to-br from-orange-900/40 to-orange-800/20 border border-orange-400/30 rounded-lg p-6 backdrop-blur-sm text-center hover:border-orange-400/50 transition-all">
            <Phone className="w-8 h-8 mx-auto mb-3 text-orange-400" />
            <h3 className="text-lg font-bold text-orange-100 mb-2">Compte Momo</h3>
            <p className="text-2xl font-bold text-orange-300 mb-3">0157579538</p>
            <button
              onClick={handleMomo}
              className="w-full bg-orange-500 hover:bg-orange-600 text-white font-bold py-2 px-4 rounded transition-colors"
            >
              Copier le numéro
            </button>
          </div>

          {/* WhatsApp Contact */}
          <div className="bg-gradient-to-br from-green-900/40 to-green-800/20 border border-green-400/30 rounded-lg p-6 backdrop-blur-sm text-center hover:border-green-400/50 transition-all">
            <MessageCircle className="w-8 h-8 mx-auto mb-3 text-green-400" />
            <h3 className="text-lg font-bold text-green-100 mb-2">WhatsApp</h3>
            <p className="text-sm text-green-200 mb-3">Contactez-nous directement</p>
            <button
              onClick={handleWhatsApp}
              className="w-full bg-green-500 hover:bg-green-600 text-white font-bold py-2 px-4 rounded transition-colors"
            >
              Ouvrir WhatsApp
            </button>
          </div>

          {/* Delivery Info */}
          <div className="bg-gradient-to-br from-blue-900/40 to-blue-800/20 border border-blue-400/30 rounded-lg p-6 backdrop-blur-sm text-center hover:border-blue-400/50 transition-all">
            <Truck className="w-8 h-8 mx-auto mb-3 text-blue-400" />
            <h3 className="text-lg font-bold text-blue-100 mb-2">Livraison</h3>
            <p className="text-blue-200 mb-3">Nous livrons partout</p>
            <div className="bg-blue-500/20 rounded p-3 border border-blue-400/30">
              <p className="text-sm text-blue-100 font-semibold">Livraison rapide et sécurisée</p>
            </div>
          </div>
        </div>

        {/* Products Grid */}
        <div className="mb-12">
          <h3 className="text-3xl font-bold text-center mb-8 text-amber-50">
            NOS PRODUITS
          </h3>

          {/* Categories */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
            {/* Wines & Champagne */}
            <div className="bg-slate-800/50 border border-amber-400/20 rounded-lg p-6 backdrop-blur-sm">
              <h4 className="text-amber-300 font-bold text-lg mb-3 uppercase tracking-wider">
                🍾 Vins & Champagnes
              </h4>
              <ul className="text-amber-50 space-y-2 text-sm">
                <li>• Martini Rosato</li>
                <li>• Martini Bianca</li>
                <li>• JP Chenet Rosé</li>
                <li>• Belaire Rosé</li>
                <li>• Champagnes Importés</li>
              </ul>
            </div>

            {/* Spirits */}
            <div className="bg-slate-800/50 border border-amber-400/20 rounded-lg p-6 backdrop-blur-sm">
              <h4 className="text-amber-300 font-bold text-lg mb-3 uppercase tracking-wider">
                🥃 Alcools Forts
              </h4>
              <ul className="text-amber-50 space-y-2 text-sm">
                <li>• Hennessy Cognac</li>
                <li>• Jack Daniel's Whiskey</li>
                <li>• Vodka Absolut</li>
                <li>• Rhum Premium</li>
                <li>• Whisky Crème</li>
              </ul>
            </div>

            {/* Beer & Sweets */}
            <div className="bg-slate-800/50 border border-amber-400/20 rounded-lg p-6 backdrop-blur-sm">
              <h4 className="text-amber-300 font-bold text-lg mb-3 uppercase tracking-wider">
                🍺 Bières & Sucreries
              </h4>
              <ul className="text-amber-50 space-y-2 text-sm">
                <li>• Bières Importées</li>
                <li>• Savanna Premium</li>
                <li>• Desperados</li>
                <li>• Sucreries en Cannette</li>
                <li>• Sélection Premium</li>
              </ul>
            </div>
          </div>

          {/* Product Images Grid */}
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-4 mb-8">
            {products.map((product, index) => (
              <div
                key={index}
                className="bg-slate-800/30 border border-amber-400/20 rounded-lg p-3 flex flex-col items-center justify-center hover:border-amber-400/50 transition-all duration-300 backdrop-blur-sm"
              >
                <img
                  src={product.image}
                  alt={product.name}
                  className="h-24 md:h-32 object-contain mb-2"
                  onError={(e) => {
                    (e.target as HTMLImageElement).src =
                      "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='100' height='100'%3E%3Crect fill='%23333' width='100' height='100'/%3E%3C/svg%3E";
                  }}
                />
                <p className="text-xs text-center text-amber-100 font-medium">
                  {product.name}
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* Call to Action */}
        <div className="bg-gradient-to-r from-amber-600 to-amber-500 rounded-lg p-8 text-center mb-12">
          <p className="text-2xl font-bold text-slate-950 mb-2">
            QUALITÉ PREMIUM • SÉLECTION EXCLUSIVE
          </p>
          <p className="text-slate-900 font-semibold">
            Découvrez notre large gamme de produits importés
          </p>
        </div>

        {/* Footer */}
        <div className="text-center border-t border-amber-400/20 pt-8">
          <p className="text-amber-200 text-sm mb-2">
            © 2025 MJ BOUTIQUE - Tous droits réservés
          </p>
          <p className="text-slate-400 text-xs">
            Votre destination pour les meilleures boissons et sucreries premium
          </p>
        </div>
      </div>

      {/* QR Code Button */}
      <div className="fixed bottom-4 right-4">
        <button
          onClick={() => setShowQRInfo(!showQRInfo)}
          className="bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-white font-bold py-3 px-4 rounded-lg shadow-2xl transition-all duration-300 transform hover:scale-105"
        >
          📱 QR Code
        </button>

        {showQRInfo && (
          <div className="absolute bottom-16 right-0 bg-white text-slate-900 p-4 rounded-lg shadow-2xl max-w-xs">
            <p className="text-sm font-bold mb-3 text-center">
              Scannez pour voir l'affiche
            </p>
            <button
              onClick={generateQRCode}
              className="w-full bg-amber-500 hover:bg-amber-600 text-white font-bold py-2 px-3 rounded transition-colors mb-2"
            >
              Générer QR Code
            </button>
            <p className="text-xs text-slate-600 text-center">
              Cliquez pour générer un code QR contenant les informations de l'affiche
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
