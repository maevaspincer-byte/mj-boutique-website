# MJ BOUTIQUE - Premium Beverages & Confectionery

Bienvenue sur le site officiel de **MJ BOUTIQUE**, votre destination pour les meilleures boissons et sucreries premium.

## 🍾 À Propos

MJ BOUTIQUE est une boutique spécialisée dans la vente de produits alcoolisés et sucreries de qualité premium, situés à **Cocotomey** (à côté de la Pharmacie Concorde, juste devant le Centre de Formation Impact Action, au bord des pavés).

## 📦 Nos Produits

### 🍾 Vins & Champagnes
- Martini Rosato
- Martini Bianca
- JP Chenet Rosé
- Belaire Rosé
- Champagnes Importés

### 🥃 Alcools Forts
- Hennessy Cognac
- Jack Daniel's Whiskey
- Vodka Absolut
- Rhum Premium
- Whisky Crème
- Vat 69
- Gold Label Reserve
- Campari
- Ballantine's
- Red Label
- Grant's
- Label 5

### 🍺 Bières & Sucreries
- Bières Importées
- Savanna Premium
- Desperados
- Sucreries en Cannette
- Sélection Premium

## 📍 Localisation

**Adresse:** Cocotomey
- À côté de la Pharmacie Concorde
- Juste devant le Centre de Formation Impact Action
- Au bord des pavés

## 📞 Nous Contacter

### 💳 Compte Momo
**0157579538**

### 💬 WhatsApp
Contactez-nous directement via WhatsApp pour vos commandes et questions.

### 🚚 Livraison
**Nous livrons partout !** Livraison rapide et sécurisée.

## 🌐 Site Web

Visitez notre site web pour voir tous nos produits et passer commande:
[https://mj-boutique.manus.space](https://mj-boutique.manus.space)

## 🎨 Design

Le site est conçu avec un design premium et élégant, mettant en avant la qualité de nos produits avec:
- Interface sombre et sophistiquée
- Accents dorés pour le prestige
- Galerie de produits complète
- Informations de contact faciles d'accès
- Code QR pour partage rapide

## 📋 Caractéristiques

✅ Affichage responsive (mobile, tablette, desktop)
✅ Galerie de produits avec images authentiques
✅ Informations de localisation détaillées
✅ Boutons de contact directs (Momo, WhatsApp)
✅ Code QR générable pour partage
✅ Design premium et professionnel

## 🛠️ Technologies

- **Frontend:** React 19 + Tailwind CSS 4
- **Icônes:** Lucide React
- **Routing:** Wouter
- **Build:** Vite

## 📄 Licence

© 2025 MJ BOUTIQUE - Tous droits réservés

## 👥 Contact

Pour toute question ou suggestion:
- 📱 Momo: 0157579538
- 💬 WhatsApp: Contactez-nous directement
- 📍 Visite: Cocotomey, Cocotomey

---

**Qualité Premium • Sélection Exclusive**

Votre destination pour les meilleures boissons et sucreries premium
