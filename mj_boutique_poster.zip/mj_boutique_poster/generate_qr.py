#!/usr/bin/env python3
import qrcode

# Create a simplified poster data
poster_data = """MJ BOUTIQUE
📍 Cocotomey - Pharmacie Concorde
Centre de Formation Impact Action - Au bord des pavés

PRODUITS PREMIUM:
🍾 Vins & Champagnes: Martini Rosato, Martini Bianca, JP Chenet, Belaire Rosé
🥃 Alcools: Hennessy, Jack Daniel's, Absolut Vodka, Rhum, Whisky
🍺 Bières & Sucreries: Savanna, Desperados, Bières Importées, Sucreries

QUALITÉ PREMIUM • SÉLECTION EXCLUSIVE
© 2025 MJ BOUTIQUE"""

# Generate QR code
qr = qrcode.QRCode(
    version=15,  # Higher version to handle the data
    error_correction=qrcode.constants.ERROR_CORRECT_L,
    box_size=10,
    border=4,
)
qr.add_data(poster_data)
qr.make(fit=False)

# Create the QR code image
qr_img = qr.make_image(fill_color="black", back_color="white")

# Save the QR code
output_path = "/home/ubuntu/mj_boutique_poster/client/public/qr_code.png"
qr_img.save(output_path)

print(f"✅ QR Code généré avec succès: {output_path}")
print(f"📊 Taille du QR Code: {qr_img.size}")
print(f"📝 Données encodées: {len(poster_data)} caractères")
print(f"\n💡 Scannez le code QR pour voir les informations de MJ Boutique!")
