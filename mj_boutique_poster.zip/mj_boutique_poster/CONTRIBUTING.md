# Guide de Contribution

Merci de votre intérêt pour MJ BOUTIQUE ! Voici comment vous pouvez contribuer :

## Comment Contribuer

1. **Fork** le repository
2. **Créez une branche** pour votre feature (`git checkout -b feature/AmazingFeature`)
3. **Committez vos changements** (`git commit -m 'Add some AmazingFeature'`)
4. **Poussez vers la branche** (`git push origin feature/AmazingFeature`)
5. **Ouvrez une Pull Request**

## Directives

- Respectez le style de code existant
- Testez vos changements avant de soumettre
- Décrivez clairement vos changements dans la Pull Request
- Assurez-vous que votre code ne casse pas les tests existants

## Questions ?

N'hésitez pas à nous contacter :
- 📱 Momo: 0157579538
- 💬 WhatsApp: Contactez-nous directement

Merci pour votre contribution !
